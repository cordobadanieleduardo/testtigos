<?php
	require_once("../configure/sesion.php");
	require_once("../configure/ConfigureSentences.php");
	require_once("../models/Mun.php");

	if (isset($_GET["dep"])) {
		$dep = $_GET["dep"];	
	} else  {
		$dep = $user_inf["deps"];
	}

	$error = ""; 
	try {
		$rep = new ConfigureSentence("t_muns");
		$data_mun = $rep->readBy("*", "id_m=" . $user_inf["muns"]);

		$rep = new ConfigureSentence("t_dpts");
		$data_dep = $rep->readBy("*", "id_d=" . $user_inf["deps"]);

		$rep = new ConfigureSentence("t_muns");
		$data_muns = $rep->readByAll("*", "id_dept=" . $user_inf["deps"], "name_mun");

		$rep = new ConfigureSentence("t_coms");
		if ($user_inf["corp"]=="JAL") {
			$data_com = $rep->readBy("*", "id_c=" . $user_inf["coms"]);
		} else {
			$data_com=[];
			$data_com["name_com"] = "";
		}

		$data=[
			"corp" => $user_inf["corp"],
			"mun" => $data_mun["name_mun"],
			"muns" => $data_muns,
			"dep" => $data_dep,
			"com" => $data_com["name_com"],
			"usr" => $user_inf["user"]["names_user"],
			"can" => $user_inf["candidato"]["name_can"]
		] ;
	} catch (Exception $e) {
		$data=[];
		$error="Error carga: coporacion {$user_inf['corp']}"; 
	}

	echo json_encode(["status"=>$error, "data"=>$data]);
?>
