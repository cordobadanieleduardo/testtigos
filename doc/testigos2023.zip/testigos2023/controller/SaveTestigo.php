<?php
	require_once("../configure/sesion.php");
	require_once("../configure/ConfigureSentences.php");

	$id=(int)$_POST["id"];
	$type=$_POST["type"];
	$cc=$_POST["cc"];
	$p_name=$_POST["p_name"];
	$s_name=$_POST["s_name"];
	$p_lastname=$_POST["p_lastname"];
	$s_lastname=$_POST["s_lastname"];
	$phone=$_POST["phone"];
	$email=$_POST["email"];
	$save=(int)$_POST["save"];

	$error="";

	if ($type=="escrutinio") {
		$data = "cc='".$cc."',p_name='".$p_name."',s_name='".$s_name."',p_last_name='".$p_lastname."',s_last_name='".$s_lastname."', email='".$email."', phone='".$phone."', save_testigos=".$save.", status_error=0, id_user='".$user_inf["user"]["id"]."'";

	} else {
		$data = "type_witnesse='".$type."',cc='".$cc."',p_name='".$p_name."',s_name='".$s_name."',p_last_name='".$p_lastname."',s_last_name='".$s_lastname."', email='".$email."', phone='".$phone."', save_testigos=".$save.", status_error=0, id_user='".$user_inf["user"]["id"]."'";
	}

	

	if ($save==1) {
		if ($cc=="" || $p_name=="" || $p_lastname=="" || $phone=="" || $email=="") {
			$error = "No se puede registrar este usuario, ya que los datos requeridos deben estar diligenciados";
			$data = [];
		} else {
			if ($type=="escrutinio") {
				$rep = new ConfigureSentence("t_zonas");
			} else {
				$rep = new ConfigureSentence("t_tables");
			}
			$data = $rep->update($data, "id_t=" . $id);
		}
	} else {
		if ($type=="escrutinio") {
			$rep = new ConfigureSentence("t_zonas");
		} else {
			$rep = new ConfigureSentence("t_tables");
		}
		$data = $rep->update($data, "id_t=" . $id);
	}
	echo json_encode(["data"=>$data, "error"=>$error]);
?>