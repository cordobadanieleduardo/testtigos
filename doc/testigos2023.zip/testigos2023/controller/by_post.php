<?php
	require_once("../configure/sesion.php");
	require_once("../configure/ConfigureSentences.php");

	$corp = $user_inf["corp"];
	$mun = $user_inf["muns"];
	$dep = $user_inf["deps"];
	$com = $user_inf["coms"];

	$rep = new ConfigureSentence("t_posts");


	if ($corp=="ALCALDE" || $corp=="CONCEJO" || $corp=="JAL") {
		$data = $rep->readByAll("*", "id_p_dept=" . $dep . " AND id_p_mun=" . $mun, "name_post");
	} elseif ($corp=="ASAMBLEA" || $corp=="GOBERNADOR") {
		$data = $rep->readByAll("*", "id_p_dept=" . $dep, "name_post");
	}

	echo json_encode($data);
?>