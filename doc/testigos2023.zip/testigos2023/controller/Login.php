<?php
    session_start();
    // require_once("../configure/sesion.php");
    require_once("../configure/ConfigureSentences.php");
    require_once("../models/Mun.php");

    $names = $_POST["names"];
    $deps = $_POST["deps"];
    $corp = $_POST["corp"];
    $muns = $_POST["muns"];
    $coms = $_POST["coms"];
    $candidato = $_POST["candidato"];

    if (isset($_SESSION)) {
        session_start();
        $_SESSION = array();

        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }

        session_destroy();
    }
    
    // $mun = $_POST["mun"];

    $rep = new ConfigureSentence("t_cands");
    $data = $rep->readBy("*", "id_ct='".$candidato."'");


    if ($data["email"]==$names) {
        $rep = new ConfigureSentence("t_user");
        $data = $rep->readBy("*", "names_user='".$names."'");

        if (!$data){
            $data = $rep->save("names_user, id_candidato", "'".$names."', '".$candidato."'");
        }

        $rep = new ConfigureSentence("t_cands");
        $candidato = $rep->readBy("*", "id_ct=".$candidato);

        // session_start();
        $_SESSION["USER_TESTIGOS"] = [
            "user"=>$data,
            "names"=>$names,
            "deps"=>$deps,
            "corp"=>$corp,
            "muns"=>$muns,
            "coms"=>$coms,
            "candidato"=>$candidato
        ];

        // echo json_encode($data);

        echo json_encode(["status" => "ok", "action" => "../index.html"]);
        die();
    } else {
        echo json_encode(["status" => "error", "action" => "El candidato que selecciono no está registrado en la plataforma del partido verde con ese correo. <b>Por favor, <a href='https://sirav.alianzaverde.org.co/cuenta/login/'>HAGA CLIC AQUÍ</a> para verificar que correo tiene asociado</b>"]);
    }

    

    // if (isset($_GET['code'])) {
    //     $code = $_GET['code'];
    //     $client_id = 'TU_ID_DE_CLIENTE'; 
    //     $client_secret = 'TU_SECRETO_DE_CLIENTE';
    //     $redirect_uri = 'TU_URL_DE_REDIRECCION';
    //     $token_url = 'https://accounts.google.com/o/oauth2/token';

    //     $params = array(
    //         'code' => $code,
    //         'client_id' => $client_id,
    //         'client_secret' => $client_secret,
    //         'redirect_uri' => $redirect_uri,
    //         'grant_type' => 'authorization_code'
    //     );

    //     $curl = curl_init($token_url);
    //     curl_setopt($curl, CURLOPT_POST, true);
    //     curl_setopt($curl, CURLOPT_POSTFIELDS, $params);
    //     curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

    //     $response = curl_exec($curl);
    //     curl_close($curl);

    //     $token = json_decode($response, true);

    //     if (isset($token['access_token'])) {
    //         // Utiliza $token['access_token'] para realizar solicitudes a la API de Google.
    //     }
    // }
?>