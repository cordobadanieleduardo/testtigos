<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../../views/source/libraries/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../../views/source/libraries/DataTables/css/jquery.dataTables.min.css">
	<link rel="stylesheet" type="text/css" href="../../views/source/style/all.css">

	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
	<title>Testigos verdes</title>
</head>
<body>

<?php 
	
	require_once("../../configure/ConfigureSentences.php");
	if (isset($_POST["pass"])) {

		$confirm_user = new ConfigureSentence("admin");
		$confirm_user=$confirm_user->readBy("*", "id=1");
		if (password_verify($_POST["pass"], $confirm_user["pass"])) {

			if (isset($_POST["type"])) {
				$type_witnesses=$_POST["type"];
			} else {
				$type_witnesses="";
			}

			$dp = new ConfigureSentence("t_posts inner join t_tables on id_p=id_post 
										inner join t_muns on id_m=id_p_mun 
										inner join t_dpts on id_d=id_p_dept
										inner join t_user on id=id_user");
			$dp = $dp->readByAll("*", " id_user!=1 AND save_testigos=1 AND type_witnesse='"  . $type_witnesses . "'", " name_dept");
			$i=0;

			#header('Content-Type: text/csv; charset=utf-8');
			#header('Content-Disposition: attachment; filename="ss"');
			#$output = fopen('MEDELLIN.csv','w');

			#fputcsv($output, array("ID", "CODDEP", "CODMUN", "CODZON", "CODPUESTO", "DEPARTAMENTO", "MUNICIPIO", "PUESTO", "MESA", "CODPAR", "CEDULA", "NOMBRE1", "NOMBRE2", "APELLIDO1", "APELLIDO2", "EMAIL", "TELEFONO", "TIPO"), ";");
?>
<!-- <div class="container-fluid">
	<br><br>
	<button class="btn btn-primary col-12" onclick="exportTableToExcel('tblData', 'TESTIGOS ELECTORALES 2023')">Exportar tabla</button>
	<br><br>
	<br>
	<table class="table" id="tblData" name="tblData" charset="utf-8">
		<thead class="table-dark">
			<th>ID</th>
			<th>CODDEP</th>
			<th>CODMUN</th>
			<th>CODZON</th>
			<th>CODPUESTO</th>
			<th>DEPARTAMENTO</th>
			<th>MUNICIPIO</th>
			<th>PUESTO</th>
			<th>MESA</th>
			<th>CODPAR</th>
			<th>CEDULA</th>
			<th>NOMBRE1</th>
			<th>NOMBRE2</th>
			<th>APELLIDO1</th>
			<th>APELLIDO2</th>
			<th>EMAIL</th>
			<th>TELEFONO</th>
			<th>TIPO</th>
		</thead>
		<tbody> -->
<?php
	$data_export="ID;CODDEP;CODMUN;CODZON;CODPUESTO;DEPARTAMENTO;MUNICIPIO;PUESTO;MESA;CODPAR;CEDULA;NOMBRE1;NOMBRE2;APELLIDO1;APELLIDO2;EMAIL;TELEFONO;TIPO;CANDIDATO<br>";
	foreach ($dp as $key => $value) {


		//$cod_dept = $value["id_d"];

		// $muns = new ConfigureSentence("t_posts inner join t_tables on id_p=id_post 
		// 								inner join t_muns on id_m=id_p_mun 
		// 								inner join t_dpts on id_d=id_p_dept");

		#header('Content-Type: text/csv; charset=utf-8');
		#header('Content-Disposition: attachment; filename="ss"');
		#$output = fopen('departamentos/'.$value["name_dept"].'.csv','w');

		#fputcsv($output, array("CODDEP", "CODMUN", "CODZON", "CODPUESTO", "DEPARTAMENTO", "MUNICIPIO", "PUESTO", "MESA", "CODPAR", "CEDULA", "NOMBRE1", "NOMBRE2", "APELLIDO1", "APELLIDO2", "EMAIL", "TELEFONO", "TIPO"), ";");

		//$data_export = $muns->readByAll("*", " id_d=" . $cod_dept . " AND id_user!=1 AND save_testigos=1", " name_dept");

		$d=new ConfigureSentence("t_tables");
		$data_export.=$value["id_t"] . ";" . $value["cod_dep"] . ";" . $value["cod_mun"] . ";" . $value["cod_zona"] . ";" . $value["cod_post"] . ";" . $value["name_dept"] . ";" . $value["name_mun"] . ";" . $value["name_post"] . ";" . $value["name_table"] . ";" . "00004" . ";" . $value["cc"] . ";" . $value["p_name"] . ";" . $value["s_name"] . ";" . $value["p_last_name"] . ";" . $value["s_last_name"] . ";" . $value["email"] . ";" . $value["phone"] . ";" . $value["type_witnesse"] . ";" . $value["names_user"] . "<br>";
        $i+=1;
		if ($value["status_export"]==0) {
			//$d=$d->update("date_export=NOW(), status_export=1", "id_t=".$value["id_t"]);
			$i+=1;

			$cod_dep="";
			$cod_mun="";
			$cod_zona="";
			$cod_post="";

			?>
				<!-- <tr>
					<td><?php //echo $value["id_t"]?></td>
					<td><?php //echo $value["cod_dep"]?></td>
					<td><?php //echo $value["cod_mun"]?></td>
					<td><?php //echo $value["cod_zona"]?></td>
					<td><?php //echo $value["cod_post"]?></td>
					<td><?php //echo $value["name_dept"]?></td>
					<td><?php //echo $value["name_mun"]?></td>
					<td><?php //echo $value["name_post"]?></td>
					<td><?php //echo $value["name_table"]?></td>
					<td><?php //echo $value["cc"]?></td>
					<td><?php //echo $value["p_name"]?></td>
					<td><?php //echo $value["s_name"]?></td>
					<td><?php //echo $value["p_last_name"]?></td>
					<td><?php //echo $value["s_last_name"]?></td>
					<td><?php //echo $value["email"]?></td>
					<td><?php //echo $value["phone"]?></td>
					<td><?php //echo $value["type_witnesse"]?></td>
				</tr> -->
			<?php
			// if (((int)$value["cod_dep"])<10) {
			// 	$cod_dep="'0" . (int)$value["cod_dep"];
			// } else {
			// 	$cod_dep=(int)$value["cod_dep"];
			// }



			// if (((int)$value["cod_mun"])>10 && ((int)$value["cod_mun"])<100) {
			// 	$cod_mun="'0" . (int)$value["cod_mun"];
			// } else {
			// 	if (((int)$value["cod_mun"])<10) {
			// 		$cod_mun="'00" . (int)$value["cod_mun"];
			// 	} else {
			// 		$cod_mun=(int)$value["cod_mun"];
			// 	}
			// }

			// if (((int)$value["cod_zona"])<10) {
			// 	$cod_zona="'0" . (int)$value["cod_zona"];
			// } else {
			// 	$cod_zona=(int)$value["cod_zona"];
			// }

			// if (((int)$value["cod_post"])<10) {
			// 	$cod_post="'0" . (int)$value["cod_post"];
			// } else {
			// 	$cod_post=(int)$value["cod_post"];
			// }

            #$data_export.=$value["id_t"] . ";" . $value["cod_dep"] . ";" . $value["cod_mun"] . ";" . $value["cod_zona"] . ";" . $value["cod_post"] . ";" . $value["name_dept"] . ";" . $value["name_mun"] . ";" . $value["name_post"] . ";" . $value["name_table"] . ";" . "00004" . ";" . $value["cc"] . ";" . $value["p_name"] . ";" . $value["s_name"] . ";" . $value["p_last_name"] . ";" . $value["s_last_name"] . ";" . $value["email"] . ";" . $value["phone"] . ";" . $value["type_witnesse"] . ";" . $value["names_user"] . "<br>";

			
			//echo json_encode($data_export);	
			#fputcsv($output, $data_export, ";");
		}
		/*foreach ($data_export as $key => $value) {
		}*/
	}
	echo $data_export;
	#echo "TOTAL FILAS AFECTADAS " . $i . "<br><br><br>";

	/*$downloadfile="TS.txt";

	header("Content-disposition: attachment; filename=$downloadfile");
	header("Content-Type: application/force-download");
	header("Content-Transfer-Encoding: binary");
	header("Content-Length: ".strlen($data_export));
	header("Pragma: no-cache");
	header("Expires: 0");*/

	?>
<!-- </div> -->
	<script type="text/javascript" src="../../views/source/libraries/jquery.js"></script>
	<script type="text/javascript" src="../../views/source/libraries/bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript">
		

		function exportTableToExcel(tableID, filename = ''){
		    var downloadLink;
		    var dataType = 'application/vnd.ms-excel; charset=utf-8';
		    var tableSelect = document.getElementById(tableID);
		    var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');

		    // Specify file name
		    filename = filename?filename+'.xls':'excel_data.xls';

		    // Create download link element
		    downloadLink = document.createElement("a");

		    document.body.appendChild(downloadLink);

		    if(navigator.msSaveOrOpenBlob){
		        var blob = new Blob(['ufeff', tableHTML], {
		            type: dataType
		        });
		        navigator.msSaveOrOpenBlob( blob, filename);
		    }else{
		        // Create a link to the file
		        downloadLink.href = 'data:' + dataType + ', ' + tableHTML;

		        // Setting the file name
		        downloadLink.download = filename;

		        //triggering the function
		        downloadLink.click();
		    }
		    //location.href="downloadTestigos.php";
		}
	</script>

	<?php
	}
}
else {

	?>
<div class="container-fluid col-6">
	<form action="downloadTestigos.php" method="post">
		<br><br>
		<div><H3>GENERAR CANDIDATOS</H3></div>
		<div>
			<label>Ingresar contraseña</label>
			<input type="password" name="pass" class="form-control">
		</div>
		<br><br>
		<div>
			<select required="" name="type" class="form-control">
				<option value="">Seleccionar tipo de testigo</option>
				<option value="predeterminado">Principal</option>
				<option value="ramanentes">Remanentes</option>
				<option value="escrutinio">Escrutinio</option>
			</select>
		</div>
		<br><br>
		<div class="d-flex justify-content-center">
			<button type="submit" class="btn btn-primary">
				Enviar
			</button>
		</div>
		
	</form>
	
</div>

<script type="text/javascript">
	//function alertar(){
	
	// input_pass =  prompt("Ingresa la contraseña");
	// input_test =  prompt("Escriba 1 para generar testigos predeterminados\n\nEscriba 2 para generar testigos remamentes\n\nEscriba 3 para generar testigos de escrutinio");
	// var type="";
	// if (input_test=="1") {
	// 	type="predeterminado";
	// } else if (input_test=="2") {
	// 	type="ramanentes";
	// } else if (input_test=="3") {
	// 	type="escrutinio";
	// }

	// location.href="downloadTestigos.php?pass="+input_pass+"&type="+type
	
</script>

	<?php
}
	//echo json_encode($data_export) . "<br>";

	#fclose($output);
	// echo json_encode($muns)
	//http://localhost/apps/app_testigos/controller/downloadTestigos.php

?>

	

		<!-- </tbody>
	</table> -->



</body>
</html>

