<?php

	require_once("../configure/sesion.php");
	require_once("../configure/ConfigureSentences.php");

	//$post = $_GET["post"];
	$type_witnesse = $_GET["type_testigos"];

	if (isset($_GET["mun"])) {
		$user_inf["muns"]=$_GET["mun"];
		$_SESSION["USER_TESTIGOS"]["muns"]=$_GET["mun"];
	}

	
	// echo json_encode($user_inf);
	if ($user_inf["deps"]==10) {
	    if ($type_witnesse=="escrutinio") {
	    	$rep = new ConfigureSentence("t_zonas join t_dpts on id_z_dept=id_d inner join t_muns on id_m=id_z_mun");
	     
			$data = $rep->readByAll("*", "id_z_dept=" . $user_inf["deps"] . " AND id_z_mun=" . $user_inf["muns"] . " AND status_error=1 AND (id_user=1 OR id_user=".$user_inf["user"]["id"].")", " name_table  ASC");
    			
    		$data_group = [];
			
    	} else {

    		$rep = new ConfigureSentence("t_posts inner join t_tables on id_post=id_p inner join t_muns on id_m=id_p_mun");
    		$data = $rep->readByAll("*", "id_p_dept=" . $user_inf["deps"] . " AND id_p_mun=" . $user_inf["muns"] . " AND id_p_com=" . $user_inf["coms"] . " AND status_error=1 AND (id_user=1 OR id_user=".$user_inf["user"]["id"].") AND type_witnesse='" . $type_witnesse . "'", " name_post  ASC");
    			
    		$data_group = [];
    		
    	}
	} else {
		if ($type_witnesse=="escrutinio") {
			$rep = new ConfigureSentence("t_zonas join t_dpts on id_z_dept=id_d inner join t_muns on id_m=id_z_mun");
		
			$data = $rep->readByAll("*", "id_z_dept=" . $user_inf["deps"] . " AND id_z_mun=" . $user_inf["muns"] . " AND status_error=1 AND (id_user=1 OR id_user=".$user_inf["user"]["id"].")", " name_table  ASC");
    			
    		$data_group = [];
		} else {

			$rep = new ConfigureSentence("t_posts inner join t_tables on id_post=id_p inner join t_muns on id_m=id_p_mun");

			$data = $rep->readByAll("*", "id_p_dept=" . $user_inf["deps"] . " AND id_p_mun=" . $user_inf["muns"] . " AND status_error=1 AND (id_user=1 OR id_user=".$user_inf["user"]["id"].") AND type_witnesse='" . $type_witnesse . "'", " name_post  ASC");
			
			$data_group = [];
		}	
	}
	
	echo json_encode(["data"=>$data, "data_group"=>$data_group]);




	/*require_once("../configure/sesion.php");
	require_once("../configure/ConfigureSentences.php");

	//$post = $_GET["post"];
	$type_witnesse = $_GET["type_testigos"];

	if (isset($_GET["mun"])) {
		$user_inf["muns"]=$_GET["mun"];
		$_SESSION["USER_TESTIGOS"]["muns"]=$_GET["mun"];
	}

	$rep = new ConfigureSentence("t_posts inner join t_tables on id_post=id_p inner join t_muns on id_m=id_p_mun");
	// echo json_encode($user_inf);
	if ($user_inf["deps"]==10) {
	    if ($type_witnesse=="escrutinio") {
	        
	        $d=[];
			$a=0;
			$cod_zona="";
			
			$zona_d = $rep->readByAll("*", "id_p_dept=" . $user_inf["deps"] . " AND id_p_mun=" . $user_inf["muns"] . " AND id_p_com=" . $user_inf["coms"] . " AND id_user!=1 AND type_witnesse='" . $type_witnesse . "'", " cod_zona");
			
			if (count($zona_d)>0) {
			    $data = $rep->readByAll("*", "id_p_dept=" . $user_inf["deps"] . " AND id_p_mun=" . $user_inf["muns"] . " AND id_p_com=" . $user_inf["coms"] . " AND save_testigos=0 AND id_user=".$user_inf["user"]["id"]." AND type_witnesse='" . $type_witnesse . "'", " cod_zona");
			    
			    for ($i=0; $i < count($data); $i++) {

    				if ($data[$i]["cod_zona"]!=$cod_zona) {
    					if ($data[$i]["id_user"]==$user_inf["user"]["id"]) {
    						$d[$a]=$data[$i];
    						$a+=1;
    					}
    					$cod_zona=$data[$i]["cod_zona"];
    				}
			    }
			} else {
			    $d = $rep->readByAll("*", "id_p_dept=" . $user_inf["deps"] . " AND id_p_mun=" . $user_inf["muns"] . " AND id_p_com=" . $user_inf["coms"] . " AND (id_user=1 OR id_user=".$user_inf["user"]["id"].") AND save_testigos=0 AND type_witnesse='" . $type_witnesse . "' GROUP BY(cod_zona)", " cod_zona");
			    
			}

			$data=$d;

			$data_group=[];  
			
    	} else {
    		$data = $rep->readByAll("*", "id_p_dept=" . $user_inf["deps"] . " AND id_p_mun=" . $user_inf["muns"] . " AND id_p_com=" . $user_inf["coms"] . " AND save_testigos=0 AND (id_user=1 OR id_user=".$user_inf["user"]["id"].") AND type_witnesse='" . $type_witnesse . "'", " name_post  ASC");
    			
    		$data_group = [];
    		
    	}
	} else {
		if ($type_witnesse=="escrutinio") {
		
			$d=[];
			$a=0;
			$cod_zona="";
			
			$zona_d = $rep->readByAll("*", "id_p_dept=" . $user_inf["deps"] . " AND id_p_mun=" . $user_inf["muns"] . " AND id_user!=1 AND type_witnesse='" . $type_witnesse . "'", " cod_zona");
			
			if (count($zona_d)>0) {
			    $data = $rep->readByAll("*", "id_p_dept=" . $user_inf["deps"] . " AND id_p_mun=" . $user_inf["muns"] . " AND save_testigos=0 AND id_user=".$user_inf["user"]["id"]." AND type_witnesse='" . $type_witnesse . "'", " cod_zona");
			    
			    for ($i=0; $i < count($data); $i++) {

    				if ($data[$i]["cod_zona"]!=$cod_zona) {
    					if ($data[$i]["id_user"]==$user_inf["user"]["id"]) {
    						$d[$a]=$data[$i];
    						$a+=1;
    					}
    					$cod_zona=$data[$i]["cod_zona"];
    				}
			    }
			} else {
			    $d = $rep->readByAll("*", "id_p_dept=" . $user_inf["deps"] . " AND id_p_mun=" . $user_inf["muns"] . " AND (id_user=1 OR id_user=".$user_inf["user"]["id"].") AND save_testigos=0 AND type_witnesse='" . $type_witnesse . "' GROUP BY(cod_zona)", " cod_zona");
			    
			}
			
			$data=$d;

			$data_group=[];
		} else {

			$data = $rep->readByAll("*", "id_p_dept=" . $user_inf["deps"] . " AND id_p_mun=" . $user_inf["muns"] . " AND save_testigos=0 AND (id_user=1 OR id_user=".$user_inf["user"]["id"].") AND type_witnesse='" . $type_witnesse . "'", " name_post  ASC");
			
			$data_group = [];
		}	
	}
	


	
	echo json_encode(["data"=>$data, "data_group"=>$data_group]);*/

?>


