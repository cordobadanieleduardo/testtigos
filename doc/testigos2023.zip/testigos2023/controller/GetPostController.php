<?php
	require_once("../configure/sesion.php");
	require_once("../configure/ConfigureSentences.php");

	$post = $_GET["post"];
	$type_witnesse = $_GET["type_testigos"];
	// $rep = new ConfigureSentence("t_posts inner join t_tables on cod_post=id_post");
	// $data = $rep->readByAll("*", "cod_post=" . $post . " AND save_testigos=0", " name_post ASC");

	$rep = new ConfigureSentence("t_posts inner join t_tables on id_p=id_post inner join t_muns on id_m=id_muns");
	$data = $rep->readByAll("*", "id_p=" . $post . " AND save_testigos=0 AND (email_user='' OR email_user='".$user_inf[0]."') AND type_witnesse='" . $type_witnesse . "'", " name_post ASC ");

	echo json_encode($data);
?>
