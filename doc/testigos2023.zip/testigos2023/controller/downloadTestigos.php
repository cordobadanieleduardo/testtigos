<?php 
	require_once("../configure/ConfigureSentences.php");
	
	$muns = new ConfigureSentence("t_muns");
	$muns = $muns->readAll("*", " name_mun");

	foreach ($muns as $key => $value) {
		$cod_mun = $value["id_m"];

		$muns = new ConfigureSentence("t_posts inner join t_tables on cod_post=id_post 
										inner join t_muns on id_m=id_muns 
										inner join t_dpts on id_d=id_dept");

		header('Content-Type: text/csv; charset=utf-8');
		header('Content-Disposition: attachment; filename="ss"');
		$output = fopen('importables/municipios/'.$value["name_mun"].'.csv','w');

		fputcsv($output, array("CODDEP", "CODMUN", "CODZON", "CODPUESTO", "DEPARTAMENTO", "MUNICIPIO", "PUESTO", "MESA", "CODPAR", "CEDULA", "NOMBRE1", "NOMBRE2", "APELLIDO1", "APELLIDO2", "EMAIL", "TELEFONO", "TIPO"), ";");

		$data_export = $muns->readByAll("cod_dep, cod_mun, cod_zona, cod_post, name_dept, name_mun, name_post, cod_table,
										'0004' as cod_partido, cc, p_name, s_name, p_last_name, s_last_name, email, phone, type_witnesse", " id_m=" . $cod_mun, " cod_mun");

		foreach ($data_export as $key => $value) {
			echo json_encode($value) . "<br>";	
			fputcsv($output, [$value["cod_dep"], $value["cod_mun"], $value["cod_zona"], $value["cod_post"], $value["name_dept"], $value["name_mun"], $value["name_post"], $value["cod_table"], $value["cod_partido"], $value["cc"], $value["p_name"], $value["s_name"], $value["p_last_name"], $value["s_last_name"], $value["email"], $value["phone"], $value["type_witnesse"]], ";");

		}

	}


		//echo json_encode($data_export) . "<br>";

	fclose($output);
	// echo json_encode($muns)
	//http://localhost/apps/app_testigos/controller/downloadTestigos.php

?>
