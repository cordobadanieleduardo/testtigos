<?php
	require_once("../../configure/ConfigureSentences.php");

	$dep = $_GET["dep"];

	$rep = new ConfigureSentence("t_muns");
	$data = $rep->readByAll("*", "id_dept=" . $dep, "name_mun ASC");

	echo json_encode($data);
?>