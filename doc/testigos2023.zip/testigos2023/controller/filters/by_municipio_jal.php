<?php
	require_once("../../configure/ConfigureSentences.php");

	$dep = $_GET["dep"];

	$rep = new ConfigureSentence("t_coms inner join t_muns on id_m=id_mun");
	$data = $rep->readByAll("*", "id_dept=" . $dep . " GROUP BY (name_mun)", "name_mun ASC");

	echo json_encode($data);
?>