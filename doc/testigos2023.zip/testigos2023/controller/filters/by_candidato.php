<?php
	require_once("../../configure/ConfigureSentences.php");

	$corp = $_GET["corp"];
	$mun = $_GET["mun"];
	$dep = $_GET["dep"];
	$com = $_GET["com"];

	$rep = new ConfigureSentence("t_cands");

	if ($corp=="ALCALDE" || $corp=="CONCEJO") {
		$data = $rep->readByAll("*", "id_dept=" . $dep . " AND id_mun=" . $mun . " AND corporation='" . $corp . "'", "name_can");
	} else if ($corp=="JAL" || $dep==10) {
		$data = $rep->readByAll("*", "id_dept=" . $dep . " AND id_mun=" . $mun  . " AND id_com=" . $com . " AND corporation='" . $corp . "'", "name_can");
	} elseif ($corp=="ASAMBLEA" || $corp=="GOBERNADOR") {
		$data = $rep->readByAll("*", "id_dept=" . $dep . " AND corporation='" . $corp . "'", "name_can");
	}

	echo json_encode($data);
?>