<?php
	require_once("../../configure/ConfigureSentences.php");

	$mun = $_GET["mun"];

	$rep = new ConfigureSentence("t_coms");
	$data = $rep->readByAll("*", "id_mun=" . $mun, " name_com ASC");

	echo json_encode($data);
?>