<?php
	// require_once("../configure/sesion.php");
	require_once("../configure/ConfigureSentences.php");
	require_once("../models/Mun.php");

	$rep = new ConfigureSentence("t_dpts");
	$data = $rep->readAll("*", "name_dept ASC");

	echo json_encode($data);
?>