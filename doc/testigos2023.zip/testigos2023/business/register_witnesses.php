<?php
	require_once ("../models/Witnesses.php");

	class RegisterWitnesses {

		function valWItTableFound ($witnesses) {
			$db_witnesses = new ConfigureSentence("t_witnesses");
			$db_witnesses->readBy("*", "id="+$witnesses->codWit);

			return $witnesses;
		}

		function valWitZonalFound ($witnesses) {
			return "";
		}
	}

?>
