<?php
	class Table {
		private $codTable;
		private $nameTable;
		private $idPost;
		private $listWitnesses;

		function __construct () {}

		public function getCodTable() {return $this->codTable}
		public function getNameTable() {return $this->nameTable}
		public function getIdPost() {return $this->idPost}
		public function getListWitnesses() {return $this->listWitnesses}

		public function setCodTable($codTable) {$this->codTable = $codTable}
		public function setNameTable($nameTable) {$this->nameTable = $nameTable}
		public function setIdPost($idPost) {$this->idPost = $idPost}
		public function setListWitnesses($listWitnesses) {$this->listWitnesses = $listWitnesses}
	}
?> 