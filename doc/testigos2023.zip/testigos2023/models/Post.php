<?php
	class Post {
		private $codPost;
		private $namePost;
		private $idMunicipio;
		private $listTable;

		function __construct () {}

		public function getCodPost() {return $this->codPost}
		public function getNamePost() {return $this->namePost}
		public function getIdPost() {return $this->idPost}
		public function getListTable() {return $this->listTable}

		public function setCodPost($codPost) {$this->codPost = $codPost}
		public function setNamePost($namePost) {$this->namePost = $namePost}
		public function setIdMunicipio($idMunicipio) {$this->idMunicipio = $idMunicipio}
		public function setListTable($listTable) {$this->listTable = $listTable}
	}
?> 