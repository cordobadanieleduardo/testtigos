<?php
	class Witnesses {
		private $codWitnesses;
		private $pNameWit;
		private $sNameWit;
		private $pLastNameWit;
		private $sLastNameWit;
		private $ccWit;
		private $emailWit;
		private $phoneWit;
		private $idTable;

		function __construct () {}

		public function getCodWitnesses() {return $this->codWitnesses}
		public function getWitpName() {return $this->pNameWit}
		public function getWitsName() {return $this->sNameWit}
		public function getWitpLastName() {return $this->pLastNameWit}
		public function getWitsLastName() {return $this->sLastNameWit}
		public function getWitcc() {return $this->ccWit}
		public function getWitemail() {return $this->emailWit}
		public function getWitphone() {return $this->phoneWit}
		public function getWitidTable() {return $this->idTable}


		public function setCodWitnesses($codWitnesses) {$this->codWitnesses=$codWitnesses}
		public function setWitpName($pNameWit) {$this->pNameWit=$pNameWit}
		public function setWitsName($sNameWit) {$this->sNameWit=$sNameWit}
		public function setWitpLastName($pLastNameWit) {$this->pLastNameWit=$pLastNameWit}
		public function setWitsLastName($sLastNameWit) {$this->sLastNameWit=$sLastNameWit}
		public function setWitcc($ccWit) {$this->ccWit=$ccWit}
		public function setWitemail($emailWit) {$this->emailWit=$emailWit}
		public function setWitphone($phoneWit) {$this->phoneWit=$phoneWit}
		public function setWitidTable($idTable) {$this->idTable=$idTable}
	}
?> 