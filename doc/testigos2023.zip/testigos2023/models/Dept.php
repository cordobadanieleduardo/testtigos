<?php
	class Dept {
		private $codDept;
		private $nameDept;
		private $listMun;

		function __construct () {}

		public function getCodDept() {return $this->codDept;}
		public function getNameDept() {return $this->nameDept;}
		public function getListMun() {return $this->listDept;}

		public function setCodDept($codDept) {$this->codDept = $codDept;}
		public function setNameDept($nameDept) {$this->nameDept = $nameDept;}
		public function setListMun($listMun) {$this->listMun = $listMun;}
	}
?> 