<?php
	class Mun {
		private $codMun;
		private $nameMun;
		private $idDept;
		private $lisPost;

		function __construct () {}

		public function getCodMun() {return $this->codMun;}
		public function getNameMun() {return $this->nameMun;}
		public function getIdDept() {return $this->idDept;}
		public function getListPost() {return $this->idDept;}

		public function setCodMun($codMun) {$this->codMun = $codMun;}
		public function setNameMun($nameMun) {$this->nameMun = $nameMun;}
		public function setIdDept($idDept) {$this->idDept = $idDept;}
		public function setListPost($ListPost) {$this->ListPost=$ListPost;}
	}
?> 