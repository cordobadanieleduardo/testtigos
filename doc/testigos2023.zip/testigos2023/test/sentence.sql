USE db_app_testigos;

/*select cod_dep, cod_mun, cod_zona, cod_post, name_dept, name_mun, name_post, cod_table,
	"0004" as cod_partido, cc, p_name, s_name, p_last_name, s_last_name, email, phone 
from t_posts inner join t_tables on cod_post=id_post 
inner join t_muns on cod_mun=id_muns 
inner join t_dpts on cod_dep=id_dept 
where id_muns="001" ORDER BY cod_post;*/

#alter table t_posts add id_p_com int;
#alter table t_posts add constraint t_posts_com_fk foreign key (id_p_com) references t_coms (id_c);
insert into t_coms values (204, "PUESTO CENSO(FERIA EXPOSICION)", 542),
(205, "PENITENCIARIA LA PICOTA", 542),
(206, "CARCEL DISTRITAL JUDICIAL MODELO", 542),
(207, "RECLUSION DE MUJERES EL BUEN PASTOR", 542),
(208, "CARCEL DISTRITAL", 542);

#update t_posts set id_p_com=nn where name_post="";
#select * from t_coms;
#select * from t_coms where id_mun=542;

select * from t_posts where id_p_mun=519;
select * from t_tables where type_witnesse="escrutinio" and id_user=3;
select * from t_user;
select * from t_dpts;
select * from t_muns;
select * from t_muns where name_mun="ALBANIA" or 
name_mun="ALBANIA" or 
name_mun="ARGELIA" or 
name_mun="ARGELIA" or 
name_mun="ARMENIA" or 
name_mun="BALBOA" or 
name_mun="BARBOSA" or 
name_mun="BELEN" or 
name_mun="BETULIA" or 
name_mun="BOLIVAR" or 
name_mun="BOLIVAR" or 
name_mun="BOLIVAR" or 
name_mun="BRICEÑO" or 
name_mun="BUENAVISTA" or 
name_mun="BUENAVISTA" or 
name_mun="BUENAVISTA" or 
name_mun="CABRERA" or 
name_mun="CALAMAR" or 
name_mun="CALDAS" or 
name_mun="CANDELARIA" or 
name_mun="CHIMA" or 
name_mun="CONCEPCION" or 
name_mun="CONCORDIA" or 
name_mun="CORDOBA" or 
name_mun="CORDOBA" or 
name_mun="EL CARMEN" or 
name_mun="EL CARMEN" or 
name_mun="EL PEÑON" or 
name_mun="EL PEÑON" or 
name_mun="EL TAMBO" or 
name_mun="FLORENCIA" or 
name_mun="GRANADA" or 
name_mun="GRANADA" or 
name_mun="GUADALUPE" or 
name_mun="GUADALUPE" or 
name_mun="GUAMAL" or 
name_mun="JERICO" or 
name_mun="LA PAZ" or 
name_mun="LA UNION" or 
name_mun="LA UNION" or 
name_mun="LA UNION" or 
name_mun="LA VEGA" or 
name_mun="LA VICTORIA" or 
name_mun="LA VICTORIA" or 
name_mun="MIRAFLORES" or 
name_mun="MORALES" or 
name_mun="MOSQUERA" or 
name_mun="NARIÑO" or 
name_mun="NARIÑO" or 
name_mun="PALESTINA" or 
name_mun="PROVIDENCIA" or 
name_mun="PUERTO COLOMBIA" or 
name_mun="PUERTO RICO" or 
name_mun="PUERTO SANTANDER" or 
name_mun="RESTREPO" or 
name_mun="RICAURTE" or 
name_mun="RIONEGRO" or 
name_mun="RIOSUCIO" or 
name_mun="SABANALARGA" or 
name_mun="SABANALARGA" or 
name_mun="SALAMINA" or 
name_mun="SAN ANDRES" or 
name_mun="SAN ANDRES" or 
name_mun="SAN BERNARDO" or 
name_mun="SAN CARLOS" or 
name_mun="SAN CAYETANO" or 
name_mun="SAN FRANCISCO" or 
name_mun="SAN FRANCISCO" or 
name_mun="SAN LUIS" or 
name_mun="SAN PABLO" or 
name_mun="SAN PEDRO" or 
name_mun="SAN PEDRO" or 
name_mun="SANTA BARBARA" or 
name_mun="SANTA MARIA" or 
name_mun="SANTA ROSA" or 
name_mun="SANTIAGO" or 
name_mun="SANTUARIO" or 
name_mun="SUAREZ" or 
name_mun="SUCRE" or 
name_mun="SUCRE" or 
name_mun="TOLEDO" or 
name_mun="VALPARAISO" or 
name_mun="VENECIA" or 
name_mun="VILLANUEVA" or 
name_mun="VILLANUEVA" or 
name_mun="VILLANUEVA";


#update t_tables set cc="", p_name="", s_name="", p_last_name="", s_last_name="", id_user=1 where id_user!=1;
