DROP DATABASE IF EXISTS db_app_testigos;
CREATE DATABASE db_app_testigos;
USE db_app_testigos;


CREATE TABLE t_dpts (
  cod_dep varchar(50) primary key not null,
  name_dept varchar(50) not null
); 

CREATE TABLE t_muns (
  cod_mun varchar(50) primary key not null,
  name_mun varchar(50) not null,
  id_dept varchar(50) not null,
  constraint id_dept_fk foreign key (id_dept) references t_dpts(cod_dep) 
);

CREATE TABLE t_zona (
  cod_zona int primary key not null,
  name_zona varchar(50) not null,
  id_muns varchar(50) not null,
  constraint id_zona_mun_fk foreign key (id_muns) references t_muns(cod_mun) 
);

CREATE TABLE t_posts (
  cod_post varchar(50) primary key not null,
  cod_zona varchar(50) not null,
  name_post varchar(50) not null,
  id_muns varchar(50) not null,
  constraint id_mun_fk foreign key (id_muns) references t_muns(cod_mun) 
);

CREATE TABLE t_tables (
  id int primary key not null auto_increment,  
  cod_table varchar(50) not null,
  name_table varchar(50) not null,
  type_witnesse varchar(25),
  cc varchar(25),
  p_name varchar(25) not null,
  s_name varchar(25),
  p_last_name varchar(25) not null,
  s_last_name varchar(25),
  email varchar(150) not null,
  phone varchar(15) not null,
  id_post varchar(50) not null,
  save_testigos int,
  email_user varchar(150) not null,
  constraint id_post_table_fk foreign key (id_post) references t_posts (cod_post)
);

CREATE TABLE t_user (
  id int primary key not null auto_increment,
  names_user varchar(150),
  id_dept varchar(50) not null,
  id_mun varchar(50),
  constraint id_user_dept_fk foreign key(id_dept) references t_dpts(cod_dep),
  constraint id_user_mun_fk foreign key(id_mun) references t_muns(cod_mun)
);

insert into t_dpts values ("01", "ANTIOQUIA"),("03", "ATLANTICO"),("05", "BOLIVAR"),("07", "BOYACA"),("09", "CALDAS"),("11", "CAUCA"),("12", "CESAR"),("13", "CORDOBA"),("15", "CUNDINAMARCA"),("16", "BOGOTA D.C."),("17", "CHOCO"),("19", "HUILA"),("21", "MAGDALENA"),("23", "NARIÑO"),("24", "RISARALDA"),("25", "NORTE DE SAN"),("26", "QUINDIO"),("27", "SANTANDER"),("28", "SUCRE"),("29", "TOLIMA"),("31", "VALLE"),("40", "ARAUCA"),("44", "CAQUETA"),("46", "CASANARE"),("48", "LA GUAJIRA"),("50", "GUAINIA"),("52", "META"),("54", "GUAVIARE"),("56", "SAN ANDRES"),("60", "AMAZONAS"),("64", "PUTUMAYO"),("68", "VAUPES"),("72", "VICHADA");
insert into t_muns values ("001", "MEDELLIN", "01"),("002", "ATRATO YUTO", "17"),("003", "CARTAGENA DEL CHAIRA", "44"),("004", "ABEJORRAL", "01"),("005", "ARENAL", "05"),("006", "ALTOS DEL ROSARIO", "05"),("007", "ABRIAQUI", "01"),("008", "AQUITANIA PUEBLOVIEJO", "07"),("009", "ARROYO HONDO", "05"),("010", "ALEJANDRIA", "01"),("011", "BOJAYA BELLAVISTA", "17"),("012", "MEDIO ATRATO BETE", "17"),("013", "AMAGA", "01"),("014", "CANTAGALLO", "05"),("015", "CICUCO", "05"),("016", "AMALFI", "01"),("017", "EL CANTON DEL SAN PABLO MAN.", "17"),("018", "CLEMENCIA", "05"),("019", "ANDES", "01"),("020", "LA APARTADA FRONTERA", "13"),("021", "BELEN DE UMBRIA", "24"),("022", "ANGELOPOLIS", "01"),("023", "LOS CORDOBAS", "13"),("024", "MOMIL", "13"),("025", "ANGOSTURA", "01"),("026", "HATILLO DE LOBA", "05"),("027", "EL PEÑON", "05"),("028", "ANORI", "01"),("029", "GUACHENE", "11"),("030", "CACHIPAY", "15"),("031", "ANTIOQUIA", "01"),("032", "PUERTO LIBERTADOR", "13"),("033", "PUERTO ESCONDIDO", "13"),("034", "ANZA", "01"),("035", "APARTADO", "01"),("036", "EL TARRA", "25"),("037", "ARBOLETES", "01"),("038", "EL LITORAL DEL SAN JUAN", "17"),("039", "ARGELIA", "01"),("040", "ARMENIA", "01"),("041", "MONTECRISTO", "05"),("042", "NUEVA GRANADA", "21"),("043", "BARBOSA", "01"),("044", "MORALES", "05"),("045", "CIMITARRA", "27"),("046", "BELMIRA", "01"),("047", "SANTA LUCIA", "03"),("048", "UNGUIA", "17"),("049", "BELLO", "01"),("050", "NOROSI", "05"),("051", "OPORAPA", "19"),("052", "BETANIA", "01"),("053", "PADILLA", "11"),("054", "MARSELLA", "24"),("055", "BETULIA", "01"),("056", "PALESTINA", "19"),("058", "BOLIVAR", "01"),("059", "PINILLOS", "05"),("060", "PIAMONTE", "11"),("061", "BURITICA", "01"),("062", "BRICEÑO", "01"),("063", "REGIDOR", "05"),("064", "CACERES", "01"),("065", "RIOVIEJO", "05"),("067", "CAICEDO", "01"),("068", "CHIQUIZA", "07"),("069", "PUERTO SANTANDER", "25"),("070", "CALDAS", "01"),("071", "EL CARMEN", "27"),("072", "EL ROSAL", "15"),("073", "CAMPAMENTO", "01"),("074", "SANTA MARIA", "19"),("075", "AGUACHICA", "12"),("076", "CAÑASGORDAS", "01"),("077", "CHIVATA", "07"),("078", "CARACOLI", "01"),("079", "CARAMANTA", "01"),("080", "CAREPA", "01"),("082", "CARMEN DE VIBORAL", "01"),("083", "MORICHAL MORICHAL NUEVO", "50"),("084", "SAN PABLO", "05"),("085", "CAROLINA", "01"),("086", "SUCRE", "11"),("087", "SUAREZ", "11"),("088", "CAUCASIA", "01"),("089", "PLANADAS", "29"),("090", "ZAPAYAN", "21"),("091", "SANTA CATALINA", "05"),("092", "SAN FELIPE", "50"),("093", "TIBU", "25"),("094", "COCORNA", "01"),("095", "SANTA ROSA DEL SUR", "05"),("096", "NARIÑO", "23"),("097", "CONCEPCION", "01"),("098", "VILLA RICA", "11"),("100", "CONCORDIA", "01"),("101", "PROVIDENCIA", "23"),("103", "COPACABANA", "01"),("105", "SALDAÑA", "29"),("106", "CHIGORODO", "01"),("109", "DABEIBA", "01"),("110", "TALAIGUA NUEVO", "05"),("112", "DON MATIAS", "01"),("113", "TIQUISIO PTO. RICO", "05"),("115", "EBEJICO", "01"),("117", "EL BAGRE", "01"),("118", "ENTRERRIOS", "01"),("119", "LA BELLEZA", "27"),("120", "SAN JOSE", "09"),("121", "ENVIGADO", "01"),("123", "SAN PEDRO DE CARTAGO", "23"),("124", "FREDONIA", "01"),("125", "SANTA BARBARA ISCUANDE", "23"),("127", "FRONTINO", "01"),("128", "GUAYABETAL", "15"),("130", "GIRALDO", "01"),("132", "GRANADA", "15"),("133", "GIRARDOTA", "01"),("136", "GOMEZ PLATA", "01"),("137", "LA VICTORIA", "07"),("139", "GRANADA", "01"),("140", "GUADALUPE", "01"),("142", "GUARNE", "01"),("145", "GUATAPE", "01"),("148", "HELICONIA", "01"),("150", "HISPANIA", "01"),("151", "ITAGUI", "01"),("154", "ITUANGO", "01"),("157", "JARDIN", "01"),("160", "JERICO", "01"),("161", "MOTAVITA", "07"),("163", "LA CEJA", "01"),("166", "LA ESTRELLA", "01"),("167", "PUERTO PARRA", "27"),("168", "PUERTO NARE-LA MAGDALENA", "01"),("169", "LA UNION", "01"),("170", "LA PINTADA", "01"),("172", "LIBORINA", "01"),("173", "OICATA", "07"),("174", "SABANA DE TORRES", "27"),("175", "MACEO", "01"),("176", "OTANCHE", "07"),("178", "MARINILLA", "01"),("179", "PAEZ", "07"),("180", "BECERRIL", "12"),("181", "MONTEBELLO", "01"),("184", "MURINDO", "01"),("187", "MUTATA", "01"),("190", "NARIÑO", "01"),("191", "NECHI", "01"),("192", "NECOCLI", "01"),("193", "OLAYA", "01"),("194", "SANTA HELENA DEL OPON", "27"),("195", "SANTA BARBARA", "27"),("196", "PEÑOL", "01"),("198", "PARATEBUENO LA NAGUAYA", "15"),("199", "PEQUE", "01"),("200", "BOSCONIA", "12"),("202", "PESCA", "07"),("205", "PUERTO BERRIO", "01"),("206", "PUERTO TRIUNFO", "01"),("208", "REMEDIOS", "01"),("211", "RETIRO", "01"),("214", "RIONEGRO", "01"),("215", "QUIPAMA", "07"),("217", "SABANALARGA", "01"),("218", "SABANETA", "01"),("219", "VETAS", "27"),("220", "SALGAR", "01"),("221", "VILLANUEVA", "27"),("223", "SAN ANDRES", "01"),("225", "CURUMANI", "12"),("226", "SAN CARLOS", "01"),("227", "SAN FRANCISCO", "01"),("229", "SAN JERONIMO", "01"),("230", "SAN JOSE DE LA MONTAÑA", "01"),("231", "SAN JUAN DE URABA", "01"),("232", "SAN LUIS", "01"),("235", "SAN PEDRO", "01"),("237", "SAN PEDRO DE URABA", "01"),("238", "SAN RAFAEL", "01"),("239", "SIBATE", "15"),("240", "SAN PEDRO", "28"),("241", "SAN ROQUE", "01"),("244", "SAN VICENTE", "01"),("247", "SANTA BARBARA", "01"),("248", "SAN MIGUEL DE SEMA", "07"),("249", "SAN PABLO DE BORBUR", "07"),("250", "SANTA ROSA DE OSOS", "01"),("251", "SANTA MARIA", "07"),("253", "SANTO DOMINGO", "01"),("256", "SANTUARIO", "01"),("259", "SEGOVIA", "01"),("260", "SINCE", "28"),("262", "SONSON", "01"),("265", "SOPETRAN", "01"),("268", "TAMESIS", "01"),("270", "TARAZA", "01"),("271", "TARSO", "01"),("274", "TITIRIBI", "01"),("277", "TOLEDO", "01"),("280", "TURBO", "01"),("281", "SORA", "07"),("282", "URAMITA", "01"),("283", "URRAO", "01"),("286", "VALDIVIA", "01"),("289", "VALPARAISO", "01"),("290", "VEGACHI", "01"),("291", "VIGIA DEL FUERTE", "01"),("292", "VENECIA", "01"),("293", "YALI", "01"),("295", "YARUMAL", "01"),("298", "YOLOMBO", "01"),("300", "YONDO-CASABE", "01"),("301", "ZARAGOZA", "01"),("304", "TIBANA", "07"),("307", "UNE", "15"),("310", "TINJACA", "07"),("311", "TIPACOQUE", "07"),("313", "TOCA", "07"),("316", "TOGUI", "07"),("318", "VENECIA", "15"),("319", "TOPAGA", "07"),("320", "TOLUVIEJO", "28"),("322", "TOTA", "07"),("323", "VILLAGOMEZ", "15"),("324", "TUNUNGUA", "07"),("325", "TURMEQUE", "07"),("328", "TUTA", "07"),("331", "TUTAZA", "07"),("334", "UMBITA", "07"),("337", "VENTAQUEMADA", "07"),("340", "VIRACACHA", "07"),("346", "ZETAQUIRA", "07"),("375", "CHIRIGUANA", "12"),("410", "EL COPEY", "12"),("415", "EL PASO", "12"),("450", "GAMARRA", "12"),("480", "LA SALINA", "46"),("520", "MANI", "46"),("525", "GONZALEZ", "12"),("540", "MONTERREY", "46"),("560", "NUNCHIA", "46"),("600", "LA GLORIA", "12"),("608", "LA JAGUA DE IBIRICO", "12"),("625", "MANAURE BALCON DEL CESAR MANA", "12"),("640", "OROCUE", "46"),("650", "PAILITAS", "12"),("680", "PAZ DE ARIPORO MORENO", "46"),("700", "PELAYA", "12"),("720", "PUEBLO BELLO", "12"),("750", "RIO DE ORO", "12"),("760", "RECETOR", "46"),("800", "SAN ALBERTO", "12"),("815", "SACAMA", "46"),("825", "LA PAZ", "12"),("830", "SAN LUIS DE PALENQUE", "46"),("840", "TAMARA", "46"),("850", "SAN DIEGO", "12"),("865", "TRINIDAD", "46"),("875", "SAN MARTIN", "12"),("880", "VILLANUEVA", "46"),("900", "TAMALAMEQUE", "12");
insert into t_posts values ("001", "01", "Comuna 3", "001"), ("002", "01", "Comuna 4", "001");
insert into t_tables (cod_table, type_witnesse, name_table, save_testigos, id_post) values ("001", "escrutinio", "1", 0, "001"), ("002", "escrutinio", "2", 0, "002"), ("003", "escrutinio","3", 0, "002"), ("004", "escrutinio", "4", 0, "002"),
	("001", "predeterminado", "1", 0, "001"), ("002", "predeterminado", "2", 0, "002"), ("003", "predeterminado","3", 0, "002"), ("004", "predeterminado", "4", 0, "002"),
    ("001", "ramanentes", "1", 0, "001"), ("002", "ramanentes", "2", 0, "002"), ("003", "ramanentes","3", 0, "002"), ("004", "ramanentes", "4", 0, "002");



