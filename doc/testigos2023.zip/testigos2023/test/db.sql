use db_app_testigos;
DROP DATABASE IF EXISTS db_app_testigos;
CREATE DATABASE db_app_testigos;

CREATE TABLE t_dpts (
  cod_dep int primary key not null,
  name_dept varchar(50) not null,
); 

CREATE TABLE t_muns (
  cod_mun int primary key not null,
  name_mun varchar(50) not null,
  id_dept int not null,
  constraint "id_dept_fk" foreign key (id_dept) references t_dpts(cod_dep) 
);

CREATE TABLE t_posts (
  cod_post int primary key not null,
  name_post varchar(50) not null,
  id_munsp int not null,
  constraint "id_mun_fk" foreign key (id_muns) references t_muns(cod_mun) 
);

CREATE TABLE t_tables (
  cod_table int primary key not null,
  name_table int primary key not null,
  id_post int not null,
  constraint "id_post_fk" foreign key (id_post) references t_posts(cod_post)  
);

CREATE TABLE t_witnesses (
  id int primary key not null auto_increment,
  type_witnesse varchar(25),
  cc varchar(25),
  p_name varchar(25) not null,
  s_name varchar(25),
  p_last_name varchar(25) not null,
  s_last_name varchar(25),
  email varchar(150) not null,
  phone varchar(15) not null,
  id_table int not null,
  constraint "id_table_fk" foreign key (id_table) references t_tables(cod_table)
);

CREATE TABLE t_rol (
  id int primary key not null auto_increment,
  rol_name varchar(50);
);

CREATE TABLE t_user (
  id int primary key not null auto_increment,
  rol_name varchar(50),
  names varchar(150),
  email varchar(150),
  phone varchar(50),
  id_dept int
  code_sesion varchar(250)
  constraint "id_dept" foreign key (id_dept) references t_depts (cod_dep)
);
