<?php
	class Conexion {
		private static $instance = null;
		private $con = null;
		
		protected function __construct(){
			$this->connection();
		}

		private function __clone(){}

		public function __wakeup(){
	        throw new \Exception("Serializable");
	    }

		public static function instance(){
			if (self::$instance==null){
				self::$instance = new Conexion();
			}
			return self::$instance;
		}

		public function connection(){
			try {
				$this->con = new PDO("mysql:host=localhost; dbname=db_app_testigos", "root", "");
				$this->con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$this->con->exec("SET CHARACTER SET utf8");
				return $this->con;
			} catch (PDOException $e){
				return "Error en la conexión";
			}
		}
	}
?>