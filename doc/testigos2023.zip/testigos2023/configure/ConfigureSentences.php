<?php
	require_once ("Conexion.php");

	class ConfigureSentence extends Conexion {

		private $entity;
		private $con;

		function __construct($entity) {
			//$this->con = new PDO("mysql:host=localhost; dbname=db_app_testigos", "root", "");
			$this->con = new PDO("mysql:host=localhost; dbname=partidoverdeorg_testigos_2023", "root", "");
			$this->con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$this->con->exec("SET CHARACTER SET utf8");
			$this->entity = $entity;
		}

		function save ($fields, $params) {
			$sql="INSERT INTO $this->entity ($fields) VALUES ($params)";
			$rs=$this->con->prepare($sql);
			$rs->execute();
			try {
				$data = $this->readMax("*");
			} catch (PDOException $e) {
				$data = null;
			}
			return $data;
		}

		function readAll ($fields, $order) {
			$sql="SELECT $fields FROM $this->entity WHERE 1 ORDER BY $order";
			$rs=$this->con->prepare($sql);
			$rs->execute();
			$data=$rs->fetchAll(PDO::FETCH_ASSOC);
			return $data;
		}

		function readMax ($fields) {
			$sql="SELECT $fields FROM $this->entity ORDER BY id DESC";
			$rs=$this->con->prepare($sql);
			$rs->execute();
			$data=$rs->fetch(PDO::FETCH_ASSOC);
			return $data;
		}

		function readByAll ($fields, $by, $order) {
			$sql="SELECT $fields FROM $this->entity WHERE $by ORDER BY $order";
			$rs=$this->con->prepare($sql);
			$rs->execute();
			$data=$rs->fetchAll(PDO::FETCH_ASSOC);
			return $data;
		} 

		function resetTable() {
			$this->delete(1);
			$sql="ALTER TABLE $this->entity AUTO_INCREMENT = 0";
			$rs=$this->con->prepare($sql);
			$rs->execute();
			$this->connection_clear ($rs);

			return $rs->rowCount();
		}

		function readBy ($fields, $by) {
			//$this->prepare_sql("read");
			$sql="SELECT $fields FROM $this->entity WHERE $by";
			$rs=$this->con->prepare($sql);
			$rs->execute();
			$data=$rs->fetch(PDO::FETCH_ASSOC);
			return $data;
		}

		function update ($fields, $by) {
			$sql="UPDATE $this->entity SET $fields WHERE $by";
			$rs=$this->con->prepare($sql);
			$rs->execute();
			$data = $this->readBy("*", $by); 
			return $data;
		}

		function join ($entity, $fields, $by) {
			$sql="SELECT $fields FROM $entity WHERE $by";
			$rs=$this->con->prepare($sql);
			$rs->execute();
			$data=$rs->fetch(PDO::FETCH_ASSOC);
			return $data;
		}

		function delete ($by) {
			$sql="DELETE FROM $this->entity WHERE $by";
			$rs=$this->con->prepare($sql);
			$rs->execute();
			return $rs->rowCount();
		}
	}

?>	