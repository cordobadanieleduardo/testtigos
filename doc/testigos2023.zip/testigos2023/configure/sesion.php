<?php
	if (!isset($_SESSION)) {
		session_start();
		if (isset($_SESSION['USER_TESTIGOS'])) {
			$user_inf=$_SESSION['USER_TESTIGOS'];
		} else {
			$user_inf = [
	            "user"=>[],
	            "names"=>"",
	            "deps"=>"",
	            "corp"=>"",
	            "muns"=>"",
	            "coms"=>"",
	            "candidato"=>[]
	        ];
		}
	} 

	$cookies = $_COOKIE;

	foreach ($cookies as $cookie_name => $cookie_value) {
        setcookie($cookie_name, '', time() - 3600);
        unset($_COOKIE[$cookie_name]);
    }
?>